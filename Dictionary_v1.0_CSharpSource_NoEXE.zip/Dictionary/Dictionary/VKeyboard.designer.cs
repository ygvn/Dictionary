﻿namespace Dictionary
{
    partial class VKeyboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button24 = new System.Windows.Forms.Button();
            this.button23 = new System.Windows.Forms.Button();
            this.button22 = new System.Windows.Forms.Button();
            this.button21 = new System.Windows.Forms.Button();
            this.button20 = new System.Windows.Forms.Button();
            this.button19 = new System.Windows.Forms.Button();
            this.button18 = new System.Windows.Forms.Button();
            this.button17 = new System.Windows.Forms.Button();
            this.button16 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.button35 = new System.Windows.Forms.Button();
            this.button34 = new System.Windows.Forms.Button();
            this.button33 = new System.Windows.Forms.Button();
            this.button32 = new System.Windows.Forms.Button();
            this.button31 = new System.Windows.Forms.Button();
            this.button30 = new System.Windows.Forms.Button();
            this.button29 = new System.Windows.Forms.Button();
            this.button28 = new System.Windows.Forms.Button();
            this.button27 = new System.Windows.Forms.Button();
            this.button26 = new System.Windows.Forms.Button();
            this.button25 = new System.Windows.Forms.Button();
            this.button36 = new System.Windows.Forms.Button();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.button37 = new System.Windows.Forms.Button();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.ForeColor = System.Drawing.Color.DarkRed;
            this.label1.Location = new System.Drawing.Point(109, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(247, 25);
            this.label1.TabIndex = 78;
            this.label1.Text = "Insert Special Characters";
            // 
            // button1
            // 
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.button1.Location = new System.Drawing.Point(12, 92);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(32, 23);
            this.button1.TabIndex = 79;
            this.button1.Text = "q";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.AllButtons_Clicked);
            // 
            // button2
            // 
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.button2.Location = new System.Drawing.Point(51, 92);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(32, 23);
            this.button2.TabIndex = 80;
            this.button2.Text = "w";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.AllButtons_Clicked);
            // 
            // button3
            // 
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.button3.Location = new System.Drawing.Point(88, 92);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(32, 23);
            this.button3.TabIndex = 81;
            this.button3.Text = "e";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.AllButtons_Clicked);
            // 
            // button4
            // 
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.button4.Location = new System.Drawing.Point(126, 92);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(32, 23);
            this.button4.TabIndex = 82;
            this.button4.Text = "r";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.AllButtons_Clicked);
            // 
            // button6
            // 
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button6.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.button6.Location = new System.Drawing.Point(202, 92);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(32, 23);
            this.button6.TabIndex = 84;
            this.button6.Text = "y";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.AllButtons_Clicked);
            // 
            // button5
            // 
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.button5.Location = new System.Drawing.Point(164, 92);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(32, 23);
            this.button5.TabIndex = 83;
            this.button5.Text = "t";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.AllButtons_Clicked);
            // 
            // button12
            // 
            this.button12.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button12.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.button12.Location = new System.Drawing.Point(430, 92);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(32, 23);
            this.button12.TabIndex = 90;
            this.button12.Text = "ü";
            this.button12.UseVisualStyleBackColor = true;
            this.button12.Click += new System.EventHandler(this.AllButtons_Clicked);
            // 
            // button11
            // 
            this.button11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button11.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.button11.Location = new System.Drawing.Point(392, 92);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(32, 23);
            this.button11.TabIndex = 89;
            this.button11.Text = "ğ";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new System.EventHandler(this.AllButtons_Clicked);
            // 
            // button10
            // 
            this.button10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button10.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.button10.Location = new System.Drawing.Point(354, 92);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(32, 23);
            this.button10.TabIndex = 88;
            this.button10.Text = "p";
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.AllButtons_Clicked);
            // 
            // button9
            // 
            this.button9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button9.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.button9.Location = new System.Drawing.Point(316, 92);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(32, 23);
            this.button9.TabIndex = 87;
            this.button9.Text = "o";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.AllButtons_Clicked);
            // 
            // button8
            // 
            this.button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button8.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.button8.Location = new System.Drawing.Point(278, 92);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(32, 23);
            this.button8.TabIndex = 86;
            this.button8.Text = "ı";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.AllButtons_Clicked);
            // 
            // button7
            // 
            this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button7.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.button7.Location = new System.Drawing.Point(240, 92);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(32, 23);
            this.button7.TabIndex = 85;
            this.button7.Text = "u";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.AllButtons_Clicked);
            // 
            // button24
            // 
            this.button24.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button24.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.button24.Location = new System.Drawing.Point(430, 121);
            this.button24.Name = "button24";
            this.button24.Size = new System.Drawing.Size(32, 23);
            this.button24.TabIndex = 102;
            this.button24.Text = ",";
            this.button24.UseVisualStyleBackColor = true;
            this.button24.Click += new System.EventHandler(this.AllButtons_Clicked);
            // 
            // button23
            // 
            this.button23.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button23.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.button23.Location = new System.Drawing.Point(392, 121);
            this.button23.Name = "button23";
            this.button23.Size = new System.Drawing.Size(32, 23);
            this.button23.TabIndex = 101;
            this.button23.Text = "i";
            this.button23.UseVisualStyleBackColor = true;
            this.button23.Click += new System.EventHandler(this.AllButtons_Clicked);
            // 
            // button22
            // 
            this.button22.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button22.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.button22.Location = new System.Drawing.Point(354, 121);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(32, 23);
            this.button22.TabIndex = 100;
            this.button22.Text = "ş";
            this.button22.UseVisualStyleBackColor = true;
            this.button22.Click += new System.EventHandler(this.AllButtons_Clicked);
            // 
            // button21
            // 
            this.button21.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button21.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.button21.Location = new System.Drawing.Point(316, 121);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(32, 23);
            this.button21.TabIndex = 99;
            this.button21.Text = "l";
            this.button21.UseVisualStyleBackColor = true;
            this.button21.Click += new System.EventHandler(this.AllButtons_Clicked);
            // 
            // button20
            // 
            this.button20.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button20.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.button20.Location = new System.Drawing.Point(278, 121);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(32, 23);
            this.button20.TabIndex = 98;
            this.button20.Text = "k";
            this.button20.UseVisualStyleBackColor = true;
            this.button20.Click += new System.EventHandler(this.AllButtons_Clicked);
            // 
            // button19
            // 
            this.button19.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button19.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.button19.Location = new System.Drawing.Point(240, 121);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(32, 23);
            this.button19.TabIndex = 97;
            this.button19.Text = "j";
            this.button19.UseVisualStyleBackColor = true;
            this.button19.Click += new System.EventHandler(this.AllButtons_Clicked);
            // 
            // button18
            // 
            this.button18.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button18.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.button18.Location = new System.Drawing.Point(202, 121);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(32, 23);
            this.button18.TabIndex = 96;
            this.button18.Text = "h";
            this.button18.UseVisualStyleBackColor = true;
            this.button18.Click += new System.EventHandler(this.AllButtons_Clicked);
            // 
            // button17
            // 
            this.button17.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button17.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.button17.Location = new System.Drawing.Point(164, 121);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(32, 23);
            this.button17.TabIndex = 95;
            this.button17.Text = "g";
            this.button17.UseVisualStyleBackColor = true;
            this.button17.Click += new System.EventHandler(this.AllButtons_Clicked);
            // 
            // button16
            // 
            this.button16.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button16.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.button16.Location = new System.Drawing.Point(126, 121);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(32, 23);
            this.button16.TabIndex = 94;
            this.button16.Text = "f";
            this.button16.UseVisualStyleBackColor = true;
            this.button16.Click += new System.EventHandler(this.AllButtons_Clicked);
            // 
            // button15
            // 
            this.button15.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button15.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.button15.Location = new System.Drawing.Point(88, 121);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(32, 23);
            this.button15.TabIndex = 93;
            this.button15.Text = "d";
            this.button15.UseVisualStyleBackColor = true;
            this.button15.Click += new System.EventHandler(this.AllButtons_Clicked);
            // 
            // button14
            // 
            this.button14.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button14.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.button14.Location = new System.Drawing.Point(51, 121);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(32, 23);
            this.button14.TabIndex = 92;
            this.button14.Text = "s";
            this.button14.UseVisualStyleBackColor = true;
            this.button14.Click += new System.EventHandler(this.AllButtons_Clicked);
            // 
            // button13
            // 
            this.button13.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button13.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.button13.Location = new System.Drawing.Point(12, 121);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(32, 23);
            this.button13.TabIndex = 91;
            this.button13.Text = "a";
            this.button13.UseVisualStyleBackColor = true;
            this.button13.Click += new System.EventHandler(this.AllButtons_Clicked);
            // 
            // button35
            // 
            this.button35.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button35.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.button35.Location = new System.Drawing.Point(13, 63);
            this.button35.Name = "button35";
            this.button35.Size = new System.Drawing.Size(32, 23);
            this.button35.TabIndex = 113;
            this.button35.Text = "\"";
            this.button35.UseVisualStyleBackColor = true;
            this.button35.Click += new System.EventHandler(this.AllButtons_Clicked);
            // 
            // button34
            // 
            this.button34.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button34.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.button34.Location = new System.Drawing.Point(354, 150);
            this.button34.Name = "button34";
            this.button34.Size = new System.Drawing.Size(32, 23);
            this.button34.TabIndex = 112;
            this.button34.Text = ".";
            this.button34.UseVisualStyleBackColor = true;
            this.button34.Click += new System.EventHandler(this.AllButtons_Clicked);
            // 
            // button33
            // 
            this.button33.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button33.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.button33.Location = new System.Drawing.Point(316, 150);
            this.button33.Name = "button33";
            this.button33.Size = new System.Drawing.Size(32, 23);
            this.button33.TabIndex = 111;
            this.button33.Text = "ç";
            this.button33.UseVisualStyleBackColor = true;
            this.button33.Click += new System.EventHandler(this.AllButtons_Clicked);
            // 
            // button32
            // 
            this.button32.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button32.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.button32.Location = new System.Drawing.Point(278, 150);
            this.button32.Name = "button32";
            this.button32.Size = new System.Drawing.Size(32, 23);
            this.button32.TabIndex = 110;
            this.button32.Text = "ö";
            this.button32.UseVisualStyleBackColor = true;
            this.button32.Click += new System.EventHandler(this.AllButtons_Clicked);
            // 
            // button31
            // 
            this.button31.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button31.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.button31.Location = new System.Drawing.Point(240, 150);
            this.button31.Name = "button31";
            this.button31.Size = new System.Drawing.Size(32, 23);
            this.button31.TabIndex = 109;
            this.button31.Text = "m";
            this.button31.UseVisualStyleBackColor = true;
            this.button31.Click += new System.EventHandler(this.AllButtons_Clicked);
            // 
            // button30
            // 
            this.button30.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button30.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.button30.Location = new System.Drawing.Point(202, 150);
            this.button30.Name = "button30";
            this.button30.Size = new System.Drawing.Size(32, 23);
            this.button30.TabIndex = 108;
            this.button30.Text = "n";
            this.button30.UseVisualStyleBackColor = true;
            this.button30.Click += new System.EventHandler(this.AllButtons_Clicked);
            // 
            // button29
            // 
            this.button29.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button29.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.button29.Location = new System.Drawing.Point(164, 150);
            this.button29.Name = "button29";
            this.button29.Size = new System.Drawing.Size(32, 23);
            this.button29.TabIndex = 107;
            this.button29.Text = "b";
            this.button29.UseVisualStyleBackColor = true;
            this.button29.Click += new System.EventHandler(this.AllButtons_Clicked);
            // 
            // button28
            // 
            this.button28.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button28.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.button28.Location = new System.Drawing.Point(126, 150);
            this.button28.Name = "button28";
            this.button28.Size = new System.Drawing.Size(32, 23);
            this.button28.TabIndex = 106;
            this.button28.Text = "v";
            this.button28.UseVisualStyleBackColor = true;
            this.button28.Click += new System.EventHandler(this.AllButtons_Clicked);
            // 
            // button27
            // 
            this.button27.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button27.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.button27.Location = new System.Drawing.Point(88, 150);
            this.button27.Name = "button27";
            this.button27.Size = new System.Drawing.Size(32, 23);
            this.button27.TabIndex = 105;
            this.button27.Text = "c";
            this.button27.UseVisualStyleBackColor = true;
            this.button27.Click += new System.EventHandler(this.AllButtons_Clicked);
            // 
            // button26
            // 
            this.button26.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button26.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.button26.Location = new System.Drawing.Point(51, 150);
            this.button26.Name = "button26";
            this.button26.Size = new System.Drawing.Size(32, 23);
            this.button26.TabIndex = 104;
            this.button26.Text = "x";
            this.button26.UseVisualStyleBackColor = true;
            this.button26.Click += new System.EventHandler(this.AllButtons_Clicked);
            // 
            // button25
            // 
            this.button25.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button25.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.button25.Location = new System.Drawing.Point(12, 150);
            this.button25.Name = "button25";
            this.button25.Size = new System.Drawing.Size(32, 23);
            this.button25.TabIndex = 103;
            this.button25.Text = "z";
            this.button25.UseVisualStyleBackColor = true;
            this.button25.Click += new System.EventHandler(this.AllButtons_Clicked);
            // 
            // button36
            // 
            this.button36.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button36.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.button36.Location = new System.Drawing.Point(88, 179);
            this.button36.Name = "button36";
            this.button36.Size = new System.Drawing.Size(298, 23);
            this.button36.TabIndex = 114;
            this.button36.Text = "s p a c e    b a r";
            this.button36.UseVisualStyleBackColor = true;
            this.button36.Click += new System.EventHandler(this.AllButtons_Clicked);
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(178, 67);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(79, 17);
            this.checkBox1.TabIndex = 116;
            this.checkBox1.Text = "UpperCase";
            this.checkBox1.UseVisualStyleBackColor = true;
            this.checkBox1.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // richTextBox1
            // 
            this.richTextBox1.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.richTextBox1.Location = new System.Drawing.Point(12, 300);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(450, 131);
            this.richTextBox1.TabIndex = 122;
            this.richTextBox1.Text = "";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(111, 281);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(23, 13);
            this.label2.TabIndex = 121;
            this.label2.Text = "To:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 281);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(33, 13);
            this.label3.TabIndex = 120;
            this.label3.Text = "From:";
            // 
            // button37
            // 
            this.button37.Location = new System.Drawing.Point(215, 276);
            this.button37.Name = "button37";
            this.button37.Size = new System.Drawing.Size(81, 23);
            this.button37.TabIndex = 119;
            this.button37.Text = "Display";
            this.button37.UseVisualStyleBackColor = true;
            this.button37.Click += new System.EventHandler(this.button37_Click);
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(140, 278);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(56, 20);
            this.textBox3.TabIndex = 118;
            this.textBox3.Text = "1125";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(51, 278);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(56, 20);
            this.textBox2.TabIndex = 117;
            this.textBox2.Text = "900";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(9, 233);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(434, 26);
            this.label4.TabIndex = 123;
            this.label4.Text = "Alternatively, copy (Ctrl-C) the character(s) from below and paste (Ctrl-V) them " +
    "into your text.\r\nSearch for any special character by entering the code number in" +
    "terval below:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(111, 34);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(282, 13);
            this.label5.TabIndex = 124;
            this.label5.Text = "Use this virtual keyboard to insert characters into your text.";
            // 
            // comboBox1
            // 
            this.comboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox1.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            " ",
            "Turkish",
            "Greek",
            "Russian"});
            this.comboBox1.Location = new System.Drawing.Point(51, 63);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 21);
            this.comboBox1.TabIndex = 125;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // VKeyboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.ClientSize = new System.Drawing.Size(474, 443);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.richTextBox1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.button37);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.checkBox1);
            this.Controls.Add(this.button36);
            this.Controls.Add(this.button35);
            this.Controls.Add(this.button34);
            this.Controls.Add(this.button33);
            this.Controls.Add(this.button32);
            this.Controls.Add(this.button31);
            this.Controls.Add(this.button30);
            this.Controls.Add(this.button29);
            this.Controls.Add(this.button28);
            this.Controls.Add(this.button27);
            this.Controls.Add(this.button26);
            this.Controls.Add(this.button25);
            this.Controls.Add(this.button24);
            this.Controls.Add(this.button23);
            this.Controls.Add(this.button22);
            this.Controls.Add(this.button21);
            this.Controls.Add(this.button20);
            this.Controls.Add(this.button19);
            this.Controls.Add(this.button18);
            this.Controls.Add(this.button17);
            this.Controls.Add(this.button16);
            this.Controls.Add(this.button15);
            this.Controls.Add(this.button14);
            this.Controls.Add(this.button13);
            this.Controls.Add(this.button12);
            this.Controls.Add(this.button11);
            this.Controls.Add(this.button10);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label1);
            this.KeyPreview = true;
            this.MaximizeBox = false;
            this.Name = "VKeyboard";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Special Characters";
            this.Load += new System.EventHandler(this.VKeyboards_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.VKeyboards_KeyDown);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button24;
        private System.Windows.Forms.Button button23;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button35;
        private System.Windows.Forms.Button button34;
        private System.Windows.Forms.Button button33;
        private System.Windows.Forms.Button button32;
        private System.Windows.Forms.Button button31;
        private System.Windows.Forms.Button button30;
        private System.Windows.Forms.Button button29;
        private System.Windows.Forms.Button button28;
        private System.Windows.Forms.Button button27;
        private System.Windows.Forms.Button button26;
        private System.Windows.Forms.Button button25;
        private System.Windows.Forms.Button button36;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button button37;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox comboBox1;
    }
}